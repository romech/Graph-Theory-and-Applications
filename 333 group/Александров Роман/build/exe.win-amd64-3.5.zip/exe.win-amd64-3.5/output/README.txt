Run the program with some arguments:
* `benchmark` to compare performance of the algorithms
* `astar` to compare heuristics for A*
* ID to find and see the shortest paths from a node chosen by id
* LAT LON coordinates to do the same by coordinate

